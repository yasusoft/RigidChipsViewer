package javavl.consts;


//==============================================================================
//	jVLTArg�N���X
//==============================================================================
public class jVLTArg
{
	public static final int CURRENT = 1;
	public static final int DIFFUSE	= 2;
	public static final int TEXTURE = 3;
	public static final int TFACTOR = 4;
	public static final int REFLMAP = 5;
	
	public static final int MIN 	= 1;
	public static final int MAX		= 5;

	
	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLTArg()
	{
		//	�f�t�H���g
	}
}