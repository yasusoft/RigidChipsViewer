package javavl.consts;


//==============================================================================
//	jVLBlend�N���X
//==============================================================================
public class jVLBlend 
{
	public static final int ZERO		 =  1;
	public static final int ONE			 =  2;
	public static final int SRCCOLOR	 =  3;
	public static final int INVSRCCOLOR	 =  4;
	public static final int SRCALPHA	 =  5;
	public static final int INVSRCALPHA	 =  6;
	public static final int DESTALPHA	 =  7;
	public static final int INVDESTALPHA =  8;
	public static final int DESTCOLOR	 =  9;
	public static final int INVDESTCOLOR = 10;
	public static final int SRCALPHASAT	 = 11;

	public static final int MIN          =  1;
	public static final int MAX          = 11;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLBlend()
	{
		//	�f�t�H���g
	}
}