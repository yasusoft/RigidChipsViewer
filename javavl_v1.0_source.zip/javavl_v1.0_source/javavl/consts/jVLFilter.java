package javavl.consts;


//==============================================================================
//	jVLFilter�N���X
//==============================================================================
public class jVLFilter
{
	public static final int POINT     = 1;
	public static final int BILINEAR  = 2;
	public static final int TRILINEAR = 3;

	public static final int MIN       = 1;
	public static final int MAX 	  = 3;

	
	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLFilter()
	{
		//	�f�t�H���g
	}
}