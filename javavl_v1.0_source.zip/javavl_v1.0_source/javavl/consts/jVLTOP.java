package javavl.consts;


//==============================================================================
//	jVLTOP�N���X
//==============================================================================
public class jVLTOP
{
	public static final int DISABLE 		  = 1;
	public static final int SELECTARG1 		  = 2;
	public static final int SELECTARG2 		  = 3;
	public static final int MODULATE 		  = 4;
	public static final int MODULATE2X 		  = 5;
	public static final int MODULATE4X 		  = 6;
	public static final int ADD 			  = 7;
	public static final int SUBTRACT 		  = 8;
	public static final int BLENDDIFFUSEALPHA = 9;
	public static final int BLENDTEXTUREALPHA = 10;
	public static final int BLENDTFACTORALPHA = 11;
	
	public static final int MIN 			  = 1;
	public static final int MAX 			  = 11;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLTOP()
	{
		//	�f�t�H���g
	}
}