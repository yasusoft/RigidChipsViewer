package javavl.consts;


//==============================================================================
//	jVLPMType�N���X
//==============================================================================
public class jVLPMType
{
	public static final int POINT 	 = 1;
	public static final int LINE 	 = 2;
	public static final int TRIANGLE = 3;

	public static final int MIN      = 1;
	public static final int MAX      = 3;

		
	//	�R���X�g���N�^	
	//--------------------------------------------------------------------------
	private jVLPMType()
	{
		//	�f�t�H���g
	}
} 