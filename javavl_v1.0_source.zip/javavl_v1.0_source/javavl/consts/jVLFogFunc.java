package javavl.consts;


//==============================================================================
//	jVLFogFunc�N���X
//==============================================================================
public class jVLFogFunc
{
	public static final int EXP    = 1;
	public static final int EXP2   = 2;
	public static final int LINEAR = 3;

	public static final int MIN    = 1;
	public static final int MAX    = 3;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLFogFunc()
	{
		//	�f�t�H���g
	}
}