package javavl.consts;


//==============================================================================
//	jVLAddress�N���X
//==============================================================================
public class jVLAddress
{
	public static final int WRAP   = 1;
	public static final int MIRROR = 2;
	public static final int CLAMP  = 3;
	public static final int BORDER = 4;
	
	public static final int MIN    = 1;
	public static final int MAX    = 4;

	
	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLAddress()
	{
		//	�f�t�H���g
	}
}