package javavl.consts;


//==============================================================================
//	jVLCullMode�N���X
//==============================================================================
public class jVLCullMode
{
	public static final int CW   = 1;		//	clockwise
	public static final int CCW  = 2;		//	counterclockwise
	public static final int NONE = 3;

	public static final int MIN  = 1;
	public static final int MAX  = 3;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLCullMode()
	{
		//	�f�t�H���g
	}
}