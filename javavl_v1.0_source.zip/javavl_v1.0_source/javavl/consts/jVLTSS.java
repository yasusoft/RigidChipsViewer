package javavl.consts;


//==============================================================================
//	jVLTSS�N���X
//==============================================================================
public class jVLTSS
{
	public static final int COLOROP       = 1;
	public static final int COLORARG1     = 2;
	public static final int COLORARG2     = 3;
	public static final int ALPHAOP       = 4;
	public static final int ALPHAARG1     = 5;
	public static final int ALPHAARG2     = 6;
	public static final int TEXCOORDINDEX = 7;
	public static final int MIPMAPLODBIAS = 8;

	public static final int MIN 		  = 1;
	public static final int MAX 		  = 8;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLTSS()
	{
		//	�f�t�H���g
	}
}