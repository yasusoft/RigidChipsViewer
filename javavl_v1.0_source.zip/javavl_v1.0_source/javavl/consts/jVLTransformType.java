package javavl.consts;


//==============================================================================
//	jVLTransformType�N���X
//==============================================================================
public class jVLTransformType
{
	public static final int WORLD      = 1;
	public static final int VIEW       = 2;
	public static final int PROJECTION = 3;

	public static final int MIN 	   = 1;
	public static final int MAX 	   = 3;
			
	
	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLTransformType()
	{
		//	�f�t�H���g
	}
}