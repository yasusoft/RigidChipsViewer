package javavl.consts;


//==============================================================================
//	jVLRS�N���X
//==============================================================================
public class jVLRS
{
	public static final int DITHERENABLE         =  1;
	public static final int FILLMODE             =  2;
	public static final int CULLMODE             =  3;
	public static final int PIXELWRITEENABLE     =  4;
	public static final int ZSORTENABLE          =  5;
	public static final int ZTESTENABLE          =  6;
	public static final int ZWRITEENABLE         =  7;
	public static final int ZBIASENABLE          =  8;
	public static final int ALPHABLENDENABLE     =  9;
	public static final int SRCBLEND             = 10;
	public static final int DESTBLEND            = 11;
	public static final int SHADEMODE            = 12;
	public static final int AMBIENT              = 13;
	public static final int TRANSFORMENABLE      = 14;
	public static final int VERTEXBLENDENABLE    = 15;
	public static final int LIGHTINGENABLE       = 16;
	public static final int SPECULARENABLE       = 17;
	public static final int STENCILENABLE        = 18;
	public static final int STENCILREF           = 19;
	public static final int STENCILFUNC          = 20;
	public static final int STENCILFAIL          = 21;
	public static final int STENCILZFAIL         = 22;
	public static final int STENCILPASS          = 23;
	public static final int TEXTUREFACTOR        = 24;
	public static final int TEXPERSPECTIVEENABLE = 25;

	public static final int MIN 			     =  1;
	public static final int MAX 			     = 25;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLRS()
	{
		//	�f�t�H���g
	};
}