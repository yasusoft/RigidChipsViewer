package javavl.consts;


//==============================================================================
//	jVLStencilOp�N���X
//==============================================================================
public class jVLStencilOp
{
	public static final int KEEP	= 1;
	public static final int ZERO 	= 2;
	public static final int REPLACE = 3;
	public static final int INCRSAT = 4;
	public static final int DECRSAT = 5;
	public static final int INVERT 	= 6;
	public static final int INCR 	= 7;
	public static final int DECR 	= 8;

	public static final int MIN     = 1;
	public static final int MAX     = 8;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLStencilOp()
	{
		//	�f�t�H���g
	}
}