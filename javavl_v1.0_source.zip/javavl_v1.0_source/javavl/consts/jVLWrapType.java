package javavl.consts;


//==============================================================================
//	jVLWrapType�N���X
//==============================================================================
public class jVLWrapType
{
	public static final int FLAT     = 1;
	public static final int CYLINDER = 2;
	public static final int SPHERE   = 3;
	public static final int CHROME   = 4;

	public static final int MIN      = 1;
	public static final int MAX      = 4;

	
	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLWrapType()
	{
		//	�f�t�H���g
	}
}