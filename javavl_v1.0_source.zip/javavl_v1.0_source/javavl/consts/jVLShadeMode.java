package javavl.consts;


//==============================================================================
//	jVLShadeMode�N���X
//==============================================================================
public class jVLShadeMode
{
	public static final int FLAT    = 1;
	public static final int GOURAUD = 2;
	public static final int PHONG   = 3;

	public static final int MIN     = 1;
	public static final int MAX     = 3;

	
	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLShadeMode()
	{
		//	�f�t�H���g
	}
}