package javavl.consts;


//==============================================================================
//	jVLBufferType�N���X
//==============================================================================
public class jVLBufferType
{
	public static final int PIXEL   = 1;
	public static final int Z 	    = 2;
	public static final int STENCIL = 4;

	
	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLBufferType()
	{
		//	�f�t�H���g
	}
}