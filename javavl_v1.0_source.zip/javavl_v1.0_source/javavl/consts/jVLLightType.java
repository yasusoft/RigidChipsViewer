package javavl.consts;


//==============================================================================
//	jVLLightType�N���X
//==============================================================================
public class jVLLightType
{
	public static final int POINT 		= 1;
	public static final int SPOT  		= 2;
	public static final int DIRECTIONAL	= 3;

	public static final int MIN         = 1;
	public static final int MAX         = 3;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLLightType()
	{
		//	�f�t�H���g
	}
}