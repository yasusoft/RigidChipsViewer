package javavl.consts;


//==============================================================================
//	jVLFillMode�N���X
//==============================================================================
public class jVLFillMode
{
	public static final int POINT     = 1;
	public static final int WIREFRAME = 2;
	public static final int SOLID     = 3;
	
	public static final int MIN       = 1;
	public static final int MAX       = 3;
	
		
	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	private jVLFillMode()
	{
		//	�f�t�H���g
	}
}