package javavl.consts;


//==============================================================================	
//	jVLCmpFunc�N���X
//==============================================================================
public class jVLCmpFunc
{
	public static final int NEVER		 = 1;
	public static final int LESS		 = 2;
	public static final int EQUAL		 = 3;
	public static final int LESSEQUAL	 = 4;
	public static final int GREATER		 = 5;
	public static final int NOTEQUAL	 = 6;
	public static final int GREATEREQUAL = 7;
	public static final int ALWAYS		 = 8;

	public static final int MIN          = 1;
	public static final int MAX          = 8;


	//	�R���X�g���N�^	
	//--------------------------------------------------------------------------
	private jVLCmpFunc()
	{
		//	�f�t�H���g
	}
}