package javavl.lower;


//==============================================================================
//	jVLTriangle�N���X
//==============================================================================
public class jVLTriangle extends jVLList
{
	public jVLVertex v1;				//	���_�@
	public jVLVertex v2;				//	���_�A
	public jVLVertex v3;				//	���_�B
	boolean front;


	//	�R���X�g���N�^
	//--------------------------------------------------------------------------
	public jVLTriangle()
	{
		super();
	}
}