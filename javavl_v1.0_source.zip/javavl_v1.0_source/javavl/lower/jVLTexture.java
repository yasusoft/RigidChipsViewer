package javavl.lower;

import javavl.consts.*;


//==============================================================================
//	jVLTexture�N���X
//==============================================================================
public class jVLTexture
{
	private final int MAX_MAPS = 16;

	jVLSurface[] map;
	int address = jVLAddress.WRAP;			//	�A�h���X���[�h
	int filter  = jVLFilter.POINT;			//	�t�B���^�[���[�h
	int bordercolor = 0xffffffff;			//	�{�[�_�[�J���[
	int nummaps = 0;						//	�}�b�v�̐�
	int LOD  = 0;							//	Level Of Detail
	int lLOD = 0;							//	low LOD
	int hLOD = 0;							//	high LOD
	int b;									//	map = (1 - b) * map[lLOD] + b * map[hLOD]
	boolean AlphaChEnable = false;			//	���`�����l���̗L����


	//	�R���X�g���N�^ 
	//--------------------------------------------------------------------------
	public jVLTexture()
	{
		//	������
		map = new jVLSurface[MAX_MAPS];
	}


	//	setTexmap
	//	�w�肳�ꂽLOD�Ƀ}�b�v��ݒ肷��
	//	�y�����zLOD    : Level Of Detail
	//			texmap : �e�N�X�`���}�b�v
	//--------------------------------------------------------------------------
	public boolean setTexmap(int LOD, jVLSurface texmap)
	{
		if(LOD < 0 || (LOD != 0 && map[LOD - 1] == null)){
			return false;
		}
		if(texmap == null || texmap.pbuf == null){
			return false;
		}

		//	�}�b�v�T�C�Y���`�F�b�N
		if(texmap.shiftwidth == -1 || texmap.shiftheight == -1){
			int width = 0;
			int height = 0;	

			//	�}�b�v�̕��𒲐�����
			if(texmap.shiftwidth == -1){
				for(int i = 0, j = 1; i < 32; i++){
					if(texmap.width < j){
						width = j >>> 1;
						break;
					}

					j <<= 1;
				}
			}else{
				width = texmap.width;
			}

			//	�}�b�v�̍����𒲐�����
			if(texmap.shiftheight == -1){
				for(int i = 0, j = 1; i < 32; i++){
					if(texmap.height < j){
						height = j >>> 1;
						break;
					}

					j <<= 1;
				}
			}else{
				height = texmap.height;
			}

			jVLSurface old_texmap = texmap;

			texmap = new jVLSurface(width, height, jVLBufferType.PIXEL);

			//	�}�b�v���k������
			for(int y = 0; y < height; y++){
				for(int x = 0; x < width; x++){
					texmap.pbuf[y * width + x] = old_texmap.pbuf[(y * old_texmap.height / height) * old_texmap.width + (x * old_texmap.width / width)];					
				}
			}
		}

		if(LOD != 0 && (texmap.shiftwidth != map[LOD - 1].shiftwidth - 1 || texmap.shiftheight != map[LOD - 1].shiftheight - 1)){
			return false;
		}

		map[LOD] = texmap;
		nummaps++;

		if(LOD == 0 && (texmap instanceof jVLImage)){
			//	texmap��jVLImage�N���X�̃C���X�^���X�Ȃ�΁A���`�����l���̗L�����𓾂�
			AlphaChEnable = ((jVLImage)texmap).AlphaChEnable;
		}

		return true;
	}


	//	getTexmap
	//	�w�肳�ꂽLOD�ɐݒ肳�ꂽ�}�b�v�𓾂�
	//	�y�����zLOD : Level Of Detail
	//--------------------------------------------------------------------------
	public jVLSurface getTexmap(int LOD)
	{
		return map[LOD];
	}


	//	setAddress
	//	�e�N�X�`���}�b�v�̃A�h���X���[�h��ݒ肷��
	//	�y�����zaddress : jVLAddress�N���X�̒萔
	//--------------------------------------------------------------------------
	public boolean setAddress(int address)
	{
		if(address < jVLAddress.MIN || address > jVLAddress.MAX)return false;

		this.address = address;

		return true;
	}


	//	getAddress
	//	�e�N�X�`���}�b�v�̃A�h���X���[�h�𓾂�
	//--------------------------------------------------------------------------
	public int getAddress()
	{
		return address;
	}


	//	setFilter
	//	�e�N�X�`���}�b�v�̃t�B���^�[���[�h��ݒ肷��
	//	�y�����zfilter : jVLFilter�N���X�̒萔
	//--------------------------------------------------------------------------
	public boolean setFilter(int filter)
	{
		if(filter < jVLFilter.MIN || filter > jVLFilter.MAX){
			return false;
		}

		this.filter = filter;

		return true;
	}


	//	getFilter
	//	�e�N�X�`���}�b�v�̃t�B���^�[���[�h��ݒ肷��
	//--------------------------------------------------------------------------
	public int getFilter()
	{
		return filter;
	}


	//	setBorderColor
	//	int�^�{�[�_�[�J���[��ݒ肷��
	//	�y�����zrgb : int�^RGB
	//--------------------------------------------------------------------------
	public void setBorderColor(int rgb)
	{
		bordercolor = 0xff << 24 | (rgb & 0xffffff);
	}


	//	getBorderColor
	//	int�^�{�[�_�[�J���[�𓾂�
	//--------------------------------------------------------------------------
	public int getBorderColor()
	{
		return bordercolor;
	}


	//	setLOD
	//	LOD��ݒ肷��
	//	�y�����zLOD : Level Of Detail
	//--------------------------------------------------------------------------
	public void setLOD(int LOD)
	{
		this.LOD = LOD;

		if(LOD < 0)this.LOD = 0;
		if(LOD >= nummaps)this.LOD = nummaps - 1;
	}


	//	�y�����zb    : lLOD-hLOD�Ԃ̓�����
	//			lLOD : low LOD
	//			hLOD : high	LOD
	//			map = (1 - b) * map[lLOD] + b * map[hLOD]
	public void setLOD(float b, int lLOD, int hLOD)
	{
		if(b < 0.0f)b = 0.0f;
		if(b > 1.0f)b = 1.0f;

		this.b    = (int)(b * 0x100);

		this.lLOD = lLOD;
		this.hLOD = hLOD;

		if(lLOD < 0)this.lLOD = 0;
		if(lLOD >= nummaps)this.lLOD = nummaps - 1;

		if(hLOD < 0)this.hLOD = 0;
		if(hLOD >= nummaps)this.hLOD = nummaps - 1;
	}


	//	generateMipmaps
	//	LOD0�ɐݒ肳�ꂽ�}�b�v����~�b�v�}�b�v�𐶐�����
	//--------------------------------------------------------------------------
	public boolean generateMipmaps()
	{
		if(map[0] == null)return false;

		int cLOD = 0;
		int nLOD = 1;

		while(true){
			jVLSurface currmap = map[cLOD];
			int nextwidth  = currmap.width >> 1;
			int nextheight = currmap.height >> 1;

			if(nextwidth == 0 || nextheight == 0)break;

			jVLImage nextmap = new jVLImage(nextwidth, nextheight);
			map[nLOD] = nextmap;

			for(int y = 0; y < nextmap.height; y++){
				for(int x = 0; x < nextmap.width; x++){
					int count = 0;
					int r = 0;
					int g = 0;
					int b = 0;
					int a = 0;
					for(int j = (y << 1) - 1; j <= (y << 1) + 1; j++){
						for(int i = (x << 1) - 1; i <= (x << 1) + 1; i++){
							if(i >= 0 && i < currmap.width && j >= 0 && j < currmap.height){
 								int texel = currmap.pbuf[currmap.width * j + i];
								r += (texel & 0xff0000) >> 16;
								g += (texel & 0xff00) >> 8;
								b += texel & 0xff;
								a += texel >>> 24;
								count++;
							}
						}
					}
					r /= count;
					g /= count;
					b /= count;
					a /= count;

					nextmap.pbuf[nextmap.width * y + x] = a << 24 | r << 16 | g << 8 | b; 
				}
			}
			cLOD++;
			nLOD++;
			nummaps++;
		}

		return true;
	}


	//	getTexelColor
	//	�e�N�Z���̃J���[�𓾂�
	//	�y�����zcolor : ����ꂽ�F���i�[����int�^�z��
	//				color[0] ... ��
	//				color[1] ... �� 
	//				color[2] ... �� �ɑΉ�
	//			u     : �}�b�v�̂����W
	//          v	  : �}�b�v�̂����W
	//--------------------------------------------------------------------------
	void getTexelColor(int[] color, float u, float v)
	{
		switch(filter){
			case jVLFilter.POINT:
				//	�|�C���g�t�B���^�����O
				jVLSurface texmap = map[LOD];
				int tU = (int)(u * (float)(texmap.width << 8)) >> 8;
				int tV = (int)(v * (float)(texmap.height << 8)) >> 8;
				int texel;				

				switch(address){
					case jVLAddress.WRAP:
						//	���b�v�A�h���X		
						texel = texmap.pbuf[((tV & texmap.maskheight) << texmap.shiftwidth) + (tU & texmap.maskwidth)];
						break;

					case jVLAddress.MIRROR:
						//	�~���[�A�h���X
						if(((tU >> texmap.shiftwidth) & 1) == 0){
							tU = tU & texmap.maskwidth;
						}else{
							tU = texmap.maskwidth - (tU & texmap.maskwidth);
						}
						if(((tV >> texmap.shiftheight) & 1) == 0){
							tV = tV & texmap.maskheight;
						}else{
							tV = texmap.maskheight - (tV & texmap.maskheight);
						}
						texel = texmap.pbuf[(tV << texmap.shiftwidth) + tU];
						break;

					case jVLAddress.CLAMP:
						//	�N�����v�A�h���X
						if(tU < 0){
							tU = 0;
						}else if(tU > texmap.maskwidth){
							tU = texmap.maskwidth;
						}
						if(tV < 0){
							tV = 0;
						}else if(tV > texmap.maskheight){
							tV = texmap.maskheight;
						}
						texel = texmap.pbuf[(tV << texmap.shiftwidth) + tU];
						break;

					case jVLAddress.BORDER:
						//	�{�[�_�[�A�h���X
						if(tU < 0 || tU > texmap.maskwidth || tV < 0 || tV > texmap.maskheight){
							texel = bordercolor;
						}else{
							texel = texmap.pbuf[(tV << texmap.shiftwidth) + tU];
						}
						break;

					default:
						texel = 0;
				}
				
				color[0] = (texel & 0xff0000) >> 16;
				color[1] = (texel & 0xff00) >> 8;
				color[2] = texel & 0xff;
				break;

			case jVLFilter.BILINEAR:
				//	�o�C���j�A�t�B���^�����O
				texmap = map[LOD];
				tU = (int)(u * (float)(texmap.width << 8));
				tV = (int)(v * (float)(texmap.height << 8));
				int tu = tU & 0xff;
				int tv = tV & 0xff;
				tU >>= 8;
				tV >>= 8;
				int sw = texmap.shiftwidth;
				int sh = texmap.shiftheight;
				int mw = texmap.maskwidth;
				int mh = texmap.maskheight;
				int tltexel, trtexel, bltexel, brtexel;

				switch(address){
					case jVLAddress.WRAP:
						//	���b�v�A�h���X
						tltexel = texmap.pbuf[(( tV      & mh) << sw) + ( tU      & mw)];
						trtexel = texmap.pbuf[(( tV      & mh) << sw) + ((tU + 1) & mw)];
						bltexel = texmap.pbuf[(((tV + 1) & mh) << sw) + ( tU      & mw)];
						brtexel = texmap.pbuf[(((tV + 1) & mh) << sw) + ((tU + 1) & mw)];
						break;

					case jVLAddress.MIRROR:
						//	�~���[�A�h���X
						int _tU, _tV;

						//	top left
						if(((tU >> sw) & 1) == 0){
							_tU = tU & mw;
						}else{
							_tU = mw - (tU & mw);
						}
						if(((tV >> sh) & 1) == 0){
							_tV = tV & mh;
						}else{
							_tV = mh - (tV & mh);
						}
						tltexel = texmap.pbuf[(_tV << sw) + _tU];

						//	top right
						tU++;	
						if(((tU >> sw) & 1) == 0){
							_tU = tU & mw;
						}else{
							_tU = mw - (tU & mw);
						}
						if(((tV >> sh) & 1) == 0){
							_tV = tV & mh;
						}else{
							_tV = mh - (tV & mh);
						}
						trtexel = texmap.pbuf[(_tV << sw) + _tU];

						//	bottom right
						tV++;
						if(((tU >> sw) & 1) == 0){
							_tU = tU & mw;
						}else{
							_tU = mw - (tU & mw);
						}
						if(((tV >> sh) & 1) == 0){
							_tV = tV & mh;
						}else{
							_tV = mh - (tV & mh);
						}
						brtexel = texmap.pbuf[(_tV << sw) + _tU];

						//	bottom left
						tU--;
						if(((tU >> sw) & 1) == 0){
							_tU = tU & mw;
						}else{
							_tU = mw - (tU & mw);
						}
						if(((tV >> sh) & 1) == 0){
							_tV = tV & mh;
						}else{
							_tV = mh - (tV & mh);
						}
						bltexel = texmap.pbuf[(_tV << sw) + _tU];
						break;

					case jVLAddress.CLAMP:
						//	�N�����v�A�h���X
						//	top left
						if(tU < 0){
							_tU = 0;
						}else if(tU > mw){
							_tU = mw;
						}else{
							_tU = tU;
						}
						if(tV < 0){
							_tV = 0;
						}else if(tV > mh){
							_tV = mh;
						}else{
							_tV = tV;
						}
						tltexel = texmap.pbuf[(_tV << sw) + _tU];

						//	top right 
						tU++;
						if(tU < 0){
							_tU = 0;
						}else if(tU > mw){
							_tU = mw;
						}else{
							_tU = tU;
						}
						if(tV < 0){
							_tV = 0;
						}else if(tV > mh){
							_tV = mh;
						}else{
							_tV = tV;
						}
						trtexel = texmap.pbuf[(_tV << sw) + _tU];

						//	bottom right
						tV++;
						if(tU < 0){
							_tU = 0;
						}else if(tU > mw){
							_tU = mw;
						}else{
							_tU = tU;
						}
						if(tV < 0){
							_tV = 0;
						}else if(tV > mh){
							_tV = mh;
						}else{
							_tV = tV;
						}
						brtexel = texmap.pbuf[(_tV << sw) + _tU];

						//	bottom left
						tU--;
						if(tU < 0){
							_tU = 0;
						}else if(tU > mw){
							_tU = mw;
						}else{
							_tU = tU;
						}
						if(tV < 0){
							_tV = 0;
						}else if(tV > mh){
							_tV = mh;
						}else{
							_tV = tV;
						}
						bltexel = texmap.pbuf[(_tV << sw) + _tU];
						break;

					case jVLAddress.BORDER:
						//	�{�[�_�[�A�h���X
						//	top left
						if(tU < 0 || tU > mw || tV < 0 || tV > mh){
							tltexel = bordercolor;
						}else{
							tltexel = texmap.pbuf[(tV << sw) + tU];
						}

						//	top right
						tU++;
						if(tU < 0 || tU > mw || tV < 0 || tV > mh){
							trtexel = bordercolor;
						}else{
							trtexel = texmap.pbuf[(tV << sw) + tU];
						}

						//	bottom right
						tV++;
						if(tU < 0 || tU > mw || tV < 0 || tV > mh){
							brtexel = bordercolor;
						}else{
							brtexel = texmap.pbuf[(tV << sw) + tU];
						}

						//	bottom left
						tU--;
						if(tU < 0 || tU > mw || tV < 0 || tV > mh){
							bltexel = bordercolor;
						}else{
							bltexel = texmap.pbuf[(tV << sw) + tU];
						}
						break;

					default:
						tltexel = 0;
						trtexel = 0;
						bltexel = 0;
						brtexel = 0;
				}

				int tlr = (tltexel & 0xff0000) >> 16;
				int tlg = (tltexel & 0xff00) >> 8;
				int tlb = tltexel & 0xff;

				int trr = (trtexel & 0xff0000) >> 16;
				int trg = (trtexel & 0xff00) >> 8;
				int trb = trtexel & 0xff;

				int blr = (bltexel & 0xff0000) >> 16;
				int blg = (bltexel & 0xff00) >> 8;
				int blb = bltexel & 0xff;

				int brr = (brtexel & 0xff0000) >> 16;
				int brg = (brtexel & 0xff00) >> 8;
				int brb = brtexel & 0xff;

				int tr = (tlr << 8) + (trr - tlr) * tu;
				int tg = (tlg << 8) + (trg - tlg) * tu;
				int tb = (tlb << 8) + (trb - tlb) * tu;

				int br = (blr << 8) + (brr - blr) * tu;
				int bg = (blg << 8) + (brg - blg) * tu;
				int bb = (blb << 8) + (brb - blb) * tu;

				color[0] = ((tr << 8) + (br - tr) * tv) >> 16;
				color[1] = ((tg << 8) + (bg - tg) * tv) >> 16;
				color[2] = ((tb << 8) + (bb - tb) * tv) >> 16;
				break;

			case jVLFilter.TRILINEAR:
				//	�g���C���j�A�t�B���^�����O
				//	[ low LOD ] 
				jVLSurface ltexmap = map[lLOD];
				int ltU = (int)(u * (float)(ltexmap.width << 8));
				int ltV = (int)(v * (float)(ltexmap.height << 8));
				int ltu = ltU & 0xff;
				int ltv = ltV & 0xff;
				ltU >>= 8;
				ltV >>= 8;
				int lsw = ltexmap.shiftwidth;
				int lsh = ltexmap.shiftheight;
				int lmw = ltexmap.maskwidth;
				int lmh = ltexmap.maskheight;
				int ltltexel, ltrtexel, lbltexel, lbrtexel;

				//	[ high LOD ]
				jVLSurface htexmap = map[hLOD];
				int htU = (int)(u * (float)(htexmap.width << 8));
				int htV = (int)(v * (float)(htexmap.height << 8));
				int htu = htU & 0xff;
				int htv = htV & 0xff;
				htU >>= 8;
				htV >>= 8;
				int hsw = htexmap.shiftwidth;
				int hsh = htexmap.shiftheight;
				int hmw = htexmap.maskwidth;
				int hmh = htexmap.maskheight;
				int htltexel, htrtexel, hbltexel, hbrtexel;

				switch(address){
					case jVLAddress.WRAP:
						//	���b�v�A�h���X
						//	[ low LOD ]
						ltltexel = ltexmap.pbuf[(( ltV      & lmh) << lsw) + ( ltU      & lmw)];
						ltrtexel = ltexmap.pbuf[(( ltV      & lmh) << lsw) + ((ltU + 1) & lmw)];
						lbltexel = ltexmap.pbuf[(((ltV + 1) & lmh) << lsw) + ( ltU      & lmw)];
						lbrtexel = ltexmap.pbuf[(((ltV + 1) & lmh) << lsw) + ((ltU + 1) & lmw)];

						//	[ high LOD ]
						htltexel = htexmap.pbuf[(( htV      & hmh) << hsw) + ( htU      & hmw)];
						htrtexel = htexmap.pbuf[(( htV      & hmh) << hsw) + ((htU + 1) & hmw)];
						hbltexel = htexmap.pbuf[(((htV + 1) & hmh) << hsw) + ( htU      & hmw)];
						hbrtexel = htexmap.pbuf[(((htV + 1) & hmh) << hsw) + ((htU + 1) & hmw)];
						break;

					case jVLAddress.MIRROR:
						//	�~���[�A�h���X
						int _tV, _tU;

						//	[ low LOD ]
						//	top left 
						if(((ltU >> lsw) & 1) == 0){
							_tU = ltU & lmw;
						}else{
							_tU = lmw - (ltU & lmw);
						}
						if(((ltV >> lsh) & 1) == 0){
							_tV = ltV & lmh;
						}else{
							_tV = lmh - (ltV & lmh);
						}
						ltltexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	top right
						ltU++;
						if(((ltU >> lsw) & 1) == 0){
							_tU = ltU & lmw;
						}else{
							_tU = lmw - (ltU & lmw);
						}
						if(((ltV >> lsh) & 1) == 0){
							_tV = ltV & lmh;
						}else{
							_tV = lmh - (ltV & lmh);
						}
						ltrtexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	bottom right
						ltV++;
						if(((ltU >> lsw) & 1) == 0){
							_tU = ltU & lmw;
						}else{
							_tU = lmw - (ltU & lmw);
						}
						if(((ltV >> lsh) & 1) == 0){
							_tV = ltV & lmh;
						}else{
							_tV = lmh - (ltV & lmh);
						}
						lbrtexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	bottom left
						ltU--;
						if(((ltU >> lsw) & 1) == 0){
							_tU = ltU & lmw;
						}else{
							_tU = lmw - (ltU & lmw);
						}
						if(((ltV >> lsh) & 1) == 0){
							_tV = ltV & lmh;
						}else{
							_tV = lmh - (ltV & lmh);
						}
						lbltexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	[ high LOD ] 
						//	top left 
						if(((htU >> hsw) & 1) == 0){
							_tU = htU & hmw;
						}else{
							_tU = hmw - (htU & hmw);
						}
						if(((htV >> hsh) & 1) == 0){
							_tV = htV & hmh;
						}else{
							_tV = hmh - (htV & hmh);
						}
						htltexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	top right
						htU++;
						if(((htU >> hsw) & 1) == 0){
							_tU = htU & hmw;
						}else{
							_tU = hmw - (htU & hmw);
						}
						if(((htV >> hsh) & 1) == 0){
							_tV = htV & hmh;
						}else{
							_tV = hmh - (htV & hmh);
						}
						htrtexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	bottom right
						htV++;
						if(((htU >> hsw) & 1) == 0){
							_tU = htU & hmw;
						}else{
							_tU = hmw - (htU & hmw);
						}
						if(((htV >> hsh) & 1) == 0){
							_tV = htV & hmh;
						}else{
							_tV = hmh - (htV & hmh);
						}
						hbrtexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	bottom left
						htU--;
						if(((htU >> hsw) & 1) == 0){
							_tU = htU & hmw;
						}else{
							_tU = hmw - (htU & hmw);
						}
						if(((htV >> hsh) & 1) == 0){
							_tV = htV & hmh;
						}else{
							_tV = hmh - (htV & hmh);
						}
						hbltexel = htexmap.pbuf[(_tV << hsw) + _tU];
						break;

					case jVLAddress.CLAMP:
						//	�N�����v�A�h���X
						//	[ low LOD ]
						//	top left
						if(ltU < 0){
							_tU = 0;	
						}else if(ltU > lmw){
							_tU = lmw;
						}else{
							_tU = ltU;
						}
						if(ltV < 0){
							_tV = 0;
						}else if(ltV > lmh){
							_tV = lmh;
						}else{
							_tV = ltV;
						}
						ltltexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	top right
						ltU++;
						if(ltU < 0){
							_tU = 0;
						}else if(ltU > lmw){
							_tU = lmw;
						}else{
							_tU = ltU;
						}
						if(ltV < 0){
							_tV = 0;
						}else if(ltV > lmh){
							_tV = lmh;
						}else{
							_tV = ltV;
						}
						ltrtexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	bottom right
						ltV++;
						if(ltU < 0){
							_tU = 0;	
						}else if(ltU > lmw){
							_tU = lmw;
						}else{
							_tU = ltU;
						}
						if(ltV < 0){
							_tV = 0;
						}else if(ltV > lmh){
							_tV = lmh;
						}else{
							_tV = ltV;
						}
						lbrtexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	bottom left
						ltU--;		
						if(ltU < 0){
							_tU = 0;
						}else if(ltU > lmw){
							_tU = lmw;
						}else{
							_tU = ltU;
						}
						if(ltV < 0){
							_tV = 0;
						}else if(ltV > lmh){
							_tV = lmh;
						}else{
							_tV = ltV;
						}
						lbltexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	[ high LOD ]
						//	top left
						if(htU < 0){
							_tU = 0;
						}else if(htU > hmw){
							_tU = hmw;
						}else{
							_tU = htU;
						}
						if(htV < 0){
							_tV = 0;
						}else if(htV > hmh){
							_tV = hmh;
						}else{
							_tV = htV;
						}
						htltexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	top right
						htU++;
						if(htU < 0){
							_tU = 0;
						}else if(htU > hmw){
							_tU = hmw;
						}else{
							_tU = htU;
						}
						if(htV < 0){
							_tV = 0;
						}else if(htV > hmh){
							_tV = hmh;
						}else{
							_tV = htV;
						}
						htrtexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	bottom right
						htV++;
						if(htU < 0){
							_tU = 0;
						}else if(htU > hmw){
							_tU = hmw;
						}else{
							_tU = htU;
						}
						if(htV < 0){
							_tV = 0;
						}else if(htV > hmh){
							_tV = hmh;
						}else{
							_tV = htV;
						}
						hbrtexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	bottom left
						htU--;
						if(htU < 0){
							_tU = 0;	
						}else if(htU > hmw){
							_tU = hmw;
						}else{
							_tU = htU;
						}
						if(htV < 0){
							_tV = 0;
						}else if(htV > hmh){
							_tV = hmh;
						}else{
							_tV = htV;
						}		
						hbltexel = htexmap.pbuf[(_tV << hsw) + _tU];
						break;

					case jVLAddress.BORDER:
						//	�{�[�_�[�A�h���X
						//	[ low LOD ]
						//	top left
						if(ltU < 0 || ltU > lmw || ltV < 0 || ltV > lmh){
							ltltexel = bordercolor;
						}else{
							ltltexel = ltexmap.pbuf[(ltV << lsw) + ltU];
						}

						//	top right
						ltU++;
						if(ltU < 0 || ltU > lmw || ltV < 0 || ltV > lmh){
							ltrtexel = bordercolor;
						}else{
							ltrtexel = ltexmap.pbuf[(ltV << lsw) + ltU];
						}

						//	bottom right
						ltV++;
						if(ltU < 0 || ltU > lmw || ltV < 0 || ltV > lmh){
							lbrtexel = bordercolor;
						}else{
							lbrtexel = ltexmap.pbuf[(ltV << lsw) + ltU];
						}

						//	bottom left
						ltU--;
						if(ltU < 0 || ltU > lmw || ltV < 0 || ltV > lmh){
							lbltexel = bordercolor;
						}else{
							lbltexel = ltexmap.pbuf[(ltV << lsw) + ltU];
						}

						//	[ high LOD ]
						//	top left
						if(htU < 0 || htU > hmw || htV < 0 || htV > hmh){
							htltexel = bordercolor;
						}else{
							htltexel = htexmap.pbuf[(htV << hsw) + htU];
						}

						//	top right
						htU++;
						if(htU < 0 || htU > hmw || htV < 0 || htV > hmh){
							htrtexel = bordercolor;
						}else{
							htrtexel = htexmap.pbuf[(htV << hsw) + htU];
						}

						//	bottom right
						htV++;
						if(htU < 0 || htU > hmw || htV < 0 || htV > hmh){
							hbrtexel = bordercolor;
						}else{
							hbrtexel = htexmap.pbuf[(htV << hsw) + htU];
						}

						//	bottom left
						htU--;
						if(htU < 0 || htU > hmw || htV < 0 || htV > hmh){
							hbltexel = bordercolor;
						}else{
							hbltexel = htexmap.pbuf[(htV << hsw) + htU];
						}
						break;

					default:
						//	[ low LOD ]
						ltltexel = 0;
						ltrtexel = 0;
						lbltexel = 0;
						lbrtexel = 0;
						
						//	[ high LOD ]
						htltexel = 0;
 						htrtexel = 0;
						hbltexel = 0;
						hbrtexel = 0;
				}

				//	[ low LOD ]
				int ltlr = (ltltexel & 0xff0000) >> 16;
				int ltlg = (ltltexel & 0xff00) >> 8;
				int ltlb = ltltexel & 0xff;

				int ltrr = (ltrtexel & 0xff0000) >> 16;
				int ltrg = (ltrtexel & 0xff00) >> 8;
				int ltrb = ltrtexel & 0xff;

				int lblr = (lbltexel & 0xff0000) >> 16;
				int lblg = (lbltexel & 0xff00) >> 8;
				int lblb = lbltexel & 0xff;

				int lbrr = (lbrtexel & 0xff0000) >> 16;
				int lbrg = (lbrtexel & 0xff00) >> 8;
				int lbrb = lbrtexel & 0xff;

				int ltr = (ltlr << 8) + (ltrr - ltlr) * ltu;
				int ltg = (ltlg << 8) + (ltrg - ltlg) * ltu;
				int ltb = (ltlb << 8) + (ltrb - ltlb) * ltu;

				int lbr = (lblr << 8) + (lbrr - lblr) * ltu;
				int lbg = (lblg << 8) + (lbrg - lblg) * ltu;
				int lbb = (lblb << 8) + (lbrb - lblb) * ltu;

				int lr = ((ltr << 8) + (lbr - ltr) * ltv) >> 16;
				int lg = ((ltg << 8) + (lbg - ltg) * ltv) >> 16;
				int lb = ((ltb << 8) + (lbb - ltb) * ltv) >> 16;

				//	[ high LOD ]
				int htlr = (htltexel & 0xff0000) >> 16;
				int htlg = (htltexel & 0xff00) >> 8;
				int htlb = htltexel & 0xff;

				int htrr = (htrtexel & 0xff0000) >> 16;
				int htrg = (htrtexel & 0xff00) >> 8;
				int htrb = htrtexel & 0xff;

				int hblr = (hbltexel & 0xff0000) >> 16;
				int hblg = (hbltexel & 0xff00) >> 8;
				int hblb = hbltexel & 0xff;

				int hbrr = (hbrtexel & 0xff0000) >> 16;
				int hbrg = (hbrtexel & 0xff00) >> 8;
				int hbrb = hbrtexel & 0xff;

				int htr = (htlr << 8) + (htrr - htlr) * htu;
				int htg = (htlg << 8) + (htrg - htlg) * htu;
				int htb = (htlb << 8) + (htrb - htlb) * htu;

				int hbr = (hblr << 8) + (hbrr - hblr) * htu;
				int hbg = (hblg << 8) + (hbrg - hblg) * htu;
				int hbb = (hblb << 8) + (hbrb - hblb) * htu;

				int hr = ((htr << 8) + (hbr - htr) * htv) >> 16;
				int hg = ((htg << 8) + (hbg - htg) * htv) >> 16;
				int hb = ((htb << 8) + (hbb - htb) * htv) >> 16;

				color[0] = ((lr << 8) + (hr - lr) * b) >> 8;
				color[1] = ((lg << 8) + (hg - lg) * b) >> 8;
				color[2] = ((lb << 8) + (hb - lb) * b) >> 8;
		}
	}


	//	getTexelAlpha
	//	�e�N�Z���̃��l�𓾂�
	//	�y�����zu : �����W
	//			v : �����W
	//--------------------------------------------------------------------------
	int getTexelAlpha(float u, float v)
	{
		switch(filter){
			case jVLFilter.POINT:
				//	�|�C���g�t�B���^�����O	
				jVLSurface texmap = map[LOD];
				int tU = (int)(u * (float)(texmap.width << 8)) >> 8;
				int tV = (int)(v * (float)(texmap.height << 8)) >> 8;
				int texel;

				switch(address){
					case jVLAddress.WRAP:
						//	���b�v�A�h���X
						texel = texmap.pbuf[((tV & texmap.maskheight) << texmap.shiftwidth) + (tU & texmap.maskwidth)];
						break;

					case jVLAddress.MIRROR:
						//	�~���[�A�h���X
						if(((tU >> texmap.shiftwidth) & 1) == 0){
							tU = tU & texmap.maskwidth;
						}else{
							tU = texmap.maskwidth - (tU & texmap.maskwidth);
						}
						if(((tV >> texmap.shiftheight) & 1) == 0){
							tV = tV & texmap.maskheight;
						}else{
							tV = texmap.maskheight - (tV & texmap.maskheight);
						}
						texel = texmap.pbuf[(tV << texmap.shiftwidth) + tU];
						break;

					case jVLAddress.CLAMP:
						//	�N�����v�A�h���X
						if(tU < 0){
							tU = 0;
						}else if(tU > texmap.maskwidth){
							tU = texmap.maskwidth;
						}
						if(tV < 0){
							tV = 0;
						}else if(tV > texmap.maskheight){
							tV = texmap.maskheight;
						}
						texel = texmap.pbuf[(tV << texmap.shiftwidth) + tU];
						break;

					case jVLAddress.BORDER:
						//	�{�[�_�[�A�h���X
						if(tU < 0 || tU > texmap.maskwidth || tV < 0 || tV > texmap.maskheight){
							texel = bordercolor;
						}else{
							texel = texmap.pbuf[(tV << texmap.shiftwidth) + tU];
						}
						break;

					default:
						texel = 0;
				}

				return texel >>> 24;

			case jVLFilter.BILINEAR:
				//	�o�C���j�A�t�B���^�����O
				texmap = map[LOD];
				tU = (int)(u * (float)(texmap.width << 8));
				tV = (int)(v * (float)(texmap.height << 8));
				int tu = tU & 0xff;
				int tv = tV & 0xff;
				tU >>= 8;
				tV >>= 8;
				int sw = texmap.shiftwidth;
				int sh = texmap.shiftheight;
				int mw = texmap.maskwidth;
				int mh = texmap.maskheight;
				int tltexel, trtexel, bltexel, brtexel;

				switch(address){
					case jVLAddress.WRAP:
						//	���b�v�A�h���X
						tltexel = texmap.pbuf[(( tV      & mh) << sw) + ( tU      & mw)];
						trtexel = texmap.pbuf[(( tV      & mh) << sw) + ((tU + 1) & mw)];
						bltexel = texmap.pbuf[(((tV + 1) & mh) << sw) + ( tU      & mw)];
						brtexel = texmap.pbuf[(((tV + 1) & mh) << sw) + ((tU + 1) & mw)];
						break;

					case jVLAddress.MIRROR:
						//	�~���[�A�h���X
						int _tU, _tV;

						//	top left
						if(((tU >> sw) & 1) == 0){
							_tU = tU & mw;
						}else{
							_tU = mw - (tU & mw);
						}	
						if(((tV >> sh) & 1) == 0){
							_tV = tV & mh;
						}else{
							_tV = mh - (tV & mh);
						}
						tltexel = texmap.pbuf[(_tV << sw) + _tU];

						//	top right
						tU++;	
						if(((tU >> sw) & 1) == 0){
							_tU = tU & mw;
						}else{
							_tU = mw - (tU & mw);
						}
						if(((tV >> sh) & 1) == 0){
							_tV = tV & mh;
						}else{
							_tV = mh - (tV & mh);
						}		
						trtexel = texmap.pbuf[(_tV << sw) + _tU];

						//	bottom right
						tV++;
						if(((tU >> sw) & 1) == 0){
							_tU = tU & mw;
						}else{
							_tU = mw - (tU & mw);
						}
						if(((tV >> sh) & 1) == 0){
							_tV = tV & mh;
						}else{
							_tV = mh - (tV & mh);
						}
						brtexel = texmap.pbuf[(_tV << sw) + _tU];

						//	bottom left
						tU--;
						if(((tU >> sw) & 1) == 0){
							_tU = tU & mw;
						}else{
							_tU = mw - (tU & mw);
						}
						if(((tV >> sh) & 1) == 0){
							_tV = tV & mh;
						}else{
							_tV = mh - (tV & mh);
						}
						bltexel = texmap.pbuf[(_tV << sw) + _tU];
						break;

					case jVLAddress.CLAMP:
						//	�N�����v�A�h���X
						//	top left
						if(tU < 0){
							_tU = 0;
						}else if(tU > mw){
							_tU = mw;
						}else{
							_tU = tU;
						}
						if(tV < 0){
							_tV = 0;
						}else if(tV > mh){
							_tV = mh;
						}else{
							_tV = tV;
						}
						tltexel = texmap.pbuf[(_tV << sw) + _tU];

						//	top right
						tU++;	
						if(tU < 0){
							_tU = 0;
						}else if(tU > mw){
							_tU = mw;
						}else{
							_tU = tU;
						}
						if(tV < 0){
							_tV = 0;
						}else if(tV > mh){
							_tV = mh;
						}else{
							_tV = tV;
						}
						trtexel = texmap.pbuf[(_tV << sw) + _tU];

						//	bottom right
						tV++;	
						if(tU < 0){
							_tU = 0;
						}else if(tU > mw){
							_tU = mw;
						}else{
							_tU = tU;
						}
						if(tV < 0){
							_tV = 0;
						}else if(tV > mh){
							_tV = mh;
						}else{
							_tV = tV;
						}
						brtexel = texmap.pbuf[(_tV << sw) + _tU];

						//	bottom left
						tU--;
						if(tU < 0){
							_tU = 0;
						}else if(tU > mw){
							_tU = mw;
						}else{
							_tU = tU;
						}
						if(tV < 0){
							_tV = 0;
						}else if(tV > mh){
							_tV = mh;
						}else{
							_tV = tV;
						}
						bltexel = texmap.pbuf[(_tV << sw) + _tU];
						break;

					case jVLAddress.BORDER:
						//	�{�[�_�[�A�h���X
						//	top left
						if(tU < 0 || tU > mw || tV < 0 || tV > mh){
							tltexel = bordercolor;
						}else{
							tltexel = texmap.pbuf[(tV << sw) + tU];
						}

						//	top right
						tU++;
						if(tU < 0 || tU > mw || tV < 0 || tV > mh){
							trtexel = bordercolor;
						}else{
							trtexel = texmap.pbuf[(tV << sw) + tU];
						}

						//	bottom right
						tV++;
						if(tU < 0 || tU > mw || tV < 0 || tV > mh){
							brtexel = bordercolor;
						}else{
							brtexel = texmap.pbuf[(tV << sw) + tU];
						}

						//	bottom left
						tU--;
						if(tU < 0 || tU > mw || tV < 0 || tV > mh){
							bltexel = bordercolor;
						}else{
							bltexel = texmap.pbuf[(tV << sw) + tU];
						}
						break;

					default:
						tltexel = 0;
						trtexel = 0;
						bltexel = 0;
						brtexel = 0;
				}

				int tla = tltexel >>> 24;
				int tra = trtexel >>> 24;
				int bla = bltexel >>> 24;
				int bra = brtexel >>> 24;

				int ta = (tla << 8) + (tra - tla) * tu;
				int ba = (bla << 8) + (bra - bla) * tu;

				return ((ta << 8) + (ba - ta) * tv) >> 16;

			case jVLFilter.TRILINEAR:
				//	�g���C���j�A�t�B���^�����O
				//	[ low LOD ] 
				jVLSurface ltexmap = map[lLOD];
				int ltU = (int)(u * (float)(ltexmap.width << 8));
				int ltV = (int)(v * (float)(ltexmap.height << 8));
				int ltu = ltU & 0xff;
				int ltv = ltV & 0xff;
				ltU >>= 8;
				ltV >>= 8;
				int lsw = ltexmap.shiftwidth;
				int lsh = ltexmap.shiftheight;
				int lmw = ltexmap.maskwidth;
				int lmh = ltexmap.maskheight;
				int ltltexel, ltrtexel, lbltexel, lbrtexel;

				//	[ high LOD ]
				jVLSurface htexmap = map[hLOD];
				int htU = (int)(u * (float)(htexmap.width << 8));
				int htV = (int)(v * (float)(htexmap.height << 8));
				int htu = htU & 0xff;
				int htv = htV & 0xff;
				htU >>= 8;
				htV >>= 8;
				int hsw = htexmap.shiftwidth;
				int hsh = htexmap.shiftheight;
				int hmw = htexmap.maskwidth;
				int hmh = htexmap.maskheight;
				int htltexel, htrtexel, hbltexel, hbrtexel;

				switch(address){
					case jVLAddress.WRAP:
						//	���b�v�A�h���X
						//	[ low LOD ]
						ltltexel = ltexmap.pbuf[(( ltV      & lmh) << lsw) + ( ltU      & lmw)];
						ltrtexel = ltexmap.pbuf[(( ltV      & lmh) << lsw) + ((ltU + 1) & lmw)];
						lbltexel = ltexmap.pbuf[(((ltV + 1) & lmh) << lsw) + ( ltU      & lmw)];
						lbrtexel = ltexmap.pbuf[(((ltV + 1) & lmh) << lsw) + ((ltU + 1) & lmw)];

						//	[ high LOD ]
						htltexel = htexmap.pbuf[(( htV      & hmh) << hsw) + ( htU      & hmw)];
						htrtexel = htexmap.pbuf[(( htV      & hmh) << hsw) + ((htU + 1) & hmw)];
						hbltexel = htexmap.pbuf[(((htV + 1) & hmh) << hsw) + ( htU      & hmw)];
						hbrtexel = htexmap.pbuf[(((htV + 1) & hmh) << hsw) + ((htU + 1) & hmw)];
						break;

					case jVLAddress.MIRROR:
						//	�~���[�A�h���X
						int _tV, _tU;

						//	[ low LOD ]
						//	top left 
						if(((ltU >> lsw) & 1) == 0){
							_tU = ltU & lmw;
						}else{
							_tU = lmw - (ltU & lmw);
						}
						if(((ltV >> lsh) & 1) == 0){
							_tV = ltV & lmh;
						}else{
							_tV = lmh - (ltV & lmh);
						}
						ltltexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	top right
						ltU++;
						if(((ltU >> lsw) & 1) == 0){
							_tU = ltU & lmw;
						}else{
							_tU = lmw - (ltU & lmw);
						}
						if(((ltV >> lsh) & 1) == 0){
							_tV = ltV & lmh;
						}else{
							_tV = lmh - (ltV & lmh);
						}
						ltrtexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	bottom right
						ltV++;
						if(((ltU >> lsw) & 1) == 0){
							_tU = ltU & lmw;
						}else{
							_tU = lmw - (ltU & lmw);
						}
						if(((ltV >> lsh) & 1) == 0){
							_tV = ltV & lmh;
						}else{
							_tV = lmh - (ltV & lmh);
						}
						lbrtexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	bottom left
						ltU--;
						if(((ltU >> lsw) & 1) == 0){
							_tU = ltU & lmw;
						}else{
							_tU = lmw - (ltU & lmw);
						}
						if(((ltV >> lsh) & 1) == 0){
							_tV = ltV & lmh;
						}else{
							_tV = lmh - (ltV & lmh);
						}
						lbltexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	[ high LOD ] 
						//	top left 
						if(((htU >> hsw) & 1) == 0){
							_tU = htU & hmw;
						}else{
							_tU = hmw - (htU & hmw);
						}
						if(((htV >> hsh) & 1) == 0){
							_tV = htV & hmh;
						}else{
							_tV = hmh - (htV & hmh);
						}
						htltexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	top right
						htU++;
						if(((htU >> hsw) & 1) == 0){
							_tU = htU & hmw;
						}else{
							_tU = hmw - (htU & hmw);
						}
						if(((htV >> hsh) & 1) == 0){
							_tV = htV & hmh;
						}else{
							_tV = hmh - (htV & hmh);
						}
						htrtexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	bottom right
						htV++;
						if(((htU >> hsw) & 1) == 0){
							_tU = htU & hmw;
						}else{
							_tU = hmw - (htU & hmw);
						}
						if(((htV >> hsh) & 1) == 0){
							_tV = htV & hmh;
						}else{
							_tV = hmh - (htV & hmh);
						}
						hbrtexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	bottom left
						htU--;
						if(((htU >> hsw) & 1) == 0){
							_tU = htU & hmw;
						}else{
							_tU = hmw - (htU & hmw);
						}
						if(((htV >> hsh) & 1) == 0){
							_tV = htV & hmh;
						}else{
							_tV = hmh - (htV & hmh);
						}
						hbltexel = htexmap.pbuf[(_tV << hsw) + _tU];
						break;

					case jVLAddress.CLAMP:
						//	�N�����v�A�h���X
						//	[ low LOD ]
						//	top left
						if(ltU < 0){
							_tU = 0;
						}else if(ltU > lmw){
							_tU = lmw;
						}else{
							_tU = ltU;
						}
						if(ltV < 0){
							_tV = 0;
						}else if(ltV > lmh){
							_tV = lmh;
						}else{
							_tV = ltV;
						}
						ltltexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	top right
						ltU++;
						if(ltU < 0){
							_tU = 0;
						}else if(ltU > lmw){
							_tU = lmw;
						}else{
							_tU = ltU;
						}
						if(ltV < 0){
							_tV = 0;
						}else if(ltV > lmh){
							_tV = lmh;
						}else{
							_tV = ltV;
						}
						ltrtexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	bottom right
						ltV++;
						if(ltU < 0){
							_tU = 0;
						}else if(ltU > lmw){
							_tU = lmw;
						}else{
							_tU = ltU;
						}
						if(ltV < 0){
							_tV = 0;
						}else if(ltV > lmh){
							_tV = lmh;
						}else{
							_tV = ltV;
						}
						lbrtexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	bottom left
						ltU--;		
						if(ltU < 0){
							_tU = 0;
						}else if(ltU > lmw){
							_tU = lmw;
						}else{
							_tU = ltU;
						}
						if(ltV < 0){
							_tV = 0;
						}else if(ltV > lmh){
							_tV = lmh;
						}else{
							_tV = ltV;
						}
						lbltexel = ltexmap.pbuf[(_tV << lsw) + _tU];

						//	[ high LOD ]
						//	top left
						if(htU < 0){
							_tU = 0;
						}else if(htU > hmw){
							_tU = hmw;
						}else{
							_tU = htU;
						}
						if(htV < 0){
							_tV = 0;
						}else if(htV > hmh){
							_tV = hmh;
						}else{
							_tV = htV;
						}
						htltexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	top right
						htU++;
						if(htU < 0){
							_tU = 0;
						}else if(htU > hmw){
							_tU = hmw;
						}else{
							_tU = htU;
						}
						if(htV < 0){
							_tV = 0;
						}else if(htV > hmh){
							_tV = hmh;
						}else{
							_tV = htV;
						}
						htrtexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	bottom right
						htV++;
						if(htU < 0){
							_tU = 0;	
						}else if(htU > hmw){
							_tU = hmw;
						}else{
							_tU = htU;
						}
						if(htV < 0){
							_tV = 0;
						}else if(htV > hmh){
							_tV = hmh;
						}else{
							_tV = htV;
						}
						hbrtexel = htexmap.pbuf[(_tV << hsw) + _tU];

						//	bottom left
						htU--;		
						if(htU < 0){
							_tU = 0;	
						}else if(htU > hmw){
							_tU = hmw;
						}else{
							_tU = htU;
						}
						if(htV < 0){
							_tV = 0;
						}else if(htV > hmh){
							_tV = hmh;
						}else{
							_tV = htV;
						}		
						hbltexel = htexmap.pbuf[(_tV << hsw) + _tU];
						break;

					case jVLAddress.BORDER:
						//	�{�[�_�[�A�h���X
						//	[ low LOD ]
						//	top left
						if(ltU < 0 || ltU > lmw || ltV < 0 || ltV > lmh){
							ltltexel = bordercolor;
						}else{
							ltltexel = ltexmap.pbuf[(ltV << lsw) + ltU];
						}

						//	top right
						ltU++;
						if(ltU < 0 || ltU > lmw || ltV < 0 || ltV > lmh){
							ltrtexel = bordercolor;
						}else{
							ltrtexel = ltexmap.pbuf[(ltV << lsw) + ltU];
						}

						//	bottom right
						ltV++;
						if(ltU < 0 || ltU > lmw || ltV < 0 || ltV > lmh){
							lbrtexel = bordercolor;
						}else{
							lbrtexel = ltexmap.pbuf[(ltV << lsw) + ltU];
						}

						//	bottom left
						ltU--;
						if(ltU < 0 || ltU > lmw || ltV < 0 || ltV > lmh){
							lbltexel = bordercolor;
						}else{
							lbltexel = ltexmap.pbuf[(ltV << lsw) + ltU];
						}

						//	[ high LOD ]
						//	top left
						if(htU < 0 || htU > hmw || htV < 0 || htV > hmh){
							htltexel = bordercolor;
						}else{
							htltexel = htexmap.pbuf[(htV << hsw) + htU];
						}

						//	top right
						htU++;
						if(htU < 0 || htU > hmw || htV < 0 || htV > hmh){
							htrtexel = bordercolor;
						}else{
							htrtexel = htexmap.pbuf[(htV << hsw) + htU];
						}

						//	bottom right
						htV++;
						if(htU < 0 || htU > hmw || htV < 0 || htV > hmh){
							hbrtexel = bordercolor;
						}else{
							hbrtexel = htexmap.pbuf[(htV << hsw) + htU];
						}

						//	bottom left
						htU--;
						if(htU < 0 || htU > hmw || htV < 0 || htV > hmh){
							hbltexel = bordercolor;
						}else{
							hbltexel = htexmap.pbuf[(htV << hsw) + htU];
						}
						break;

					default:
						//	[ low LOD ]
						ltltexel = 0;
						ltrtexel = 0;
						lbltexel = 0;
						lbrtexel = 0;
						
						//	[ high LOD ]
						htltexel = 0;
 						htrtexel = 0;
						hbltexel = 0;
						hbrtexel = 0;
				}

				//	[ low LOD ]
				int ltla = ltltexel >>> 24;
				int ltra = ltrtexel >>> 24;
				int lbla = lbltexel >>> 24;
				int lbra = lbrtexel >>> 24;

				int lta = (ltla << 8) + (ltra - ltla) * ltu;
				int lba = (lbla << 8) + (lbra - lbla) * ltu;

				int la = ((lta << 8) + (lba - lta) * ltv) >> 16;

				//	[ high LOD ]
				int htla = htltexel >>> 24;
				int htra = htrtexel >>> 24;
				int hbla = hbltexel >>> 24;
				int hbra = hbrtexel >>> 24;

				int hta = (htla << 8) + (htra - htla) * htu;
				int hba = (hbla << 8) + (hbra - hbla) * htu;

				int ha = ((hta << 8) + (hba - hta) * ltv) >> 16;

				return ((la << 8) + (ha - la) * b) >> 8;
		}

		return 0;
	}
}
